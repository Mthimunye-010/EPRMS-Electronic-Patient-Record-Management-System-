from django.contrib import admin

from .models import Patient


@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ("hospital_number", "full_name", "sa_id_number", "gender", "date_of_birth", "is_active")
    search_fields = ("hospital_number", "sa_id_number", "first_name", "last_name")
    list_filter = ("gender", "is_active")
    readonly_fields = ("hospital_number", "created_at", "updated_at")
