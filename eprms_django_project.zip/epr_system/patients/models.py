from django.conf import settings
from django.core.validators import RegexValidator
from django.db import models
from django.urls import reverse

sa_id_validator = RegexValidator(
    regex=r"^\d{13}$",
    message="South African ID numbers must be exactly 13 digits.",
)


class Patient(models.Model):
    """
    Core patient record.

    Duplicate detection (Business Objective 3.3 / Success Criteria 7.2) is
    implemented using the South African ID number as the primary unique
    identifier, with a secondary check on name + date of birth to catch
    cases where the ID was mistyped.
    """

    class Gender(models.TextChoices):
        MALE = "M", "Male"
        FEMALE = "F", "Female"
        OTHER = "O", "Other"

    hospital_number = models.CharField(
        max_length=20,
        unique=True,
        editable=False,
        help_text="Automatically generated, unique hospital record number.",
    )
    sa_id_number = models.CharField(
        max_length=13,
        unique=True,
        validators=[sa_id_validator],
        verbose_name="South African ID number",
    )
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=1, choices=Gender.choices)
    phone_number = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    address = models.TextField(blank=True)
    next_of_kin_name = models.CharField(max_length=150, blank=True)
    next_of_kin_phone = models.CharField(max_length=20, blank=True)

    registered_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="patients_registered"
    )
    is_active = models.BooleanField(default=True, help_text="Inactive patients are archived, not deleted.")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["last_name", "first_name"]
        indexes = [
            models.Index(fields=["sa_id_number"]),
            models.Index(fields=["last_name", "first_name"]),
            models.Index(fields=["hospital_number"]),
        ]

    def __str__(self):
        return f"{self.full_name} ({self.hospital_number})"

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    def get_absolute_url(self):
        return reverse("patients:patient_detail", kwargs={"pk": self.pk})

    def save(self, *args, **kwargs):
        if not self.hospital_number:
            self.hospital_number = self._generate_hospital_number()
        super().save(*args, **kwargs)

    @staticmethod
    def _generate_hospital_number():
        """Generates a sequential, human readable hospital number like HOSP-000123."""
        last = Patient.objects.order_by("-id").first()
        next_id = (last.id + 1) if last else 1
        return f"HOSP-{next_id:06d}"

    @classmethod
    def find_potential_duplicates(cls, sa_id_number=None, first_name="", last_name="", date_of_birth=None, exclude_pk=None):
        """
        Returns a queryset of patients that may already represent the same
        person, based on:
          1. An exact SA ID number match (strong signal), or
          2. Matching first name + last name + date of birth (in case the ID
             was captured incorrectly).
        """
        query = models.Q()
        if sa_id_number:
            query |= models.Q(sa_id_number=sa_id_number)
        if first_name and last_name and date_of_birth:
            query |= models.Q(
                first_name__iexact=first_name,
                last_name__iexact=last_name,
                date_of_birth=date_of_birth,
            )
        if not query:
            return cls.objects.none()

        qs = cls.objects.filter(query)
        if exclude_pk:
            qs = qs.exclude(pk=exclude_pk)
        return qs
