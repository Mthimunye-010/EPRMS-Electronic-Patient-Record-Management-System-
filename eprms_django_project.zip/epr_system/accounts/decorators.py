from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect


def role_required(*allowed_roles):
    """
    Restrict a view to users whose `.role` is in `allowed_roles`.
    Administrators are always allowed through.

    Usage:
        @role_required('DOCTOR', 'NURSE')
        def my_view(request):
            ...
    """

    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def _wrapped(request, *args, **kwargs):
            user = request.user
            if user.role == user.Role.ADMIN or user.role in allowed_roles:
                return view_func(request, *args, **kwargs)
            messages.error(request, "You do not have permission to access that page.")
            raise PermissionDenied("Insufficient role for this action.")

        return _wrapped

    return decorator


class RoleRequiredMixin:
    """Class-based view mixin equivalent of `role_required`."""

    allowed_roles = ()

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect("accounts:login")
        if request.user.role == request.user.Role.ADMIN or request.user.role in self.allowed_roles:
            return super().dispatch(request, *args, **kwargs)
        messages.error(request, "You do not have permission to access that page.")
        raise PermissionDenied("Insufficient role for this action.")
