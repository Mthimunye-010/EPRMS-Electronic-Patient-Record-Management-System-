from django.contrib import admin

from .models import Appointment, Consultation, MedicalHistoryEntry, Medication


@admin.register(MedicalHistoryEntry)
class MedicalHistoryEntryAdmin(admin.ModelAdmin):
    list_display = ("patient", "category", "recorded_by", "recorded_at")
    list_filter = ("category",)


@admin.register(Consultation)
class ConsultationAdmin(admin.ModelAdmin):
    list_display = ("patient", "doctor", "date")


@admin.register(Medication)
class MedicationAdmin(admin.ModelAdmin):
    list_display = ("patient", "name", "start_date", "end_date")


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ("patient", "doctor", "date", "time", "status")
    list_filter = ("status",)
