from .models import AuditLog


def _client_ip(request):
    if request is None:
        return None
    forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR")


def log_action(request, action, target=None, description=""):
    """
    Create an AuditLog entry.

    `target` may be any model instance (Patient, Consultation, User, ...).
    """
    user = getattr(request, "user", None)
    if user is not None and not user.is_authenticated:
        user = None

    AuditLog.objects.create(
        user=user,
        username_snapshot=(user.username if user else "system"),
        action=action,
        target_model=target.__class__.__name__ if target is not None else "",
        target_id=str(getattr(target, "pk", "")) if target is not None else "",
        target_repr=str(target) if target is not None else "",
        description=description,
        ip_address=_client_ip(request),
    )
