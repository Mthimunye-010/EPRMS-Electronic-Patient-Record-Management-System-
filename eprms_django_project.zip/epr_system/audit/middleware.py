import threading

_thread_locals = threading.local()


class CurrentUserMiddleware:
    """Stashes the current request so audit logging utilities (and other
    code that isn't handed a request directly) can access the IP address
    and authenticated user."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        _thread_locals.request = request
        try:
            response = self.get_response(request)
        finally:
            _thread_locals.request = None
        return response


def get_current_request():
    return getattr(_thread_locals, "request", None)
